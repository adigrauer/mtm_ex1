#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "amount_set_str_tests.h"
#include "tests/test_utilities.h"

int main()
{
  RUN_TEST(test1);
  RUN_TEST(test2);
  RUN_TEST(test3);
  RUN_TEST(test4);
  return 0;
}