#ifndef AMOUNT_SET_STR_TESTS_H
#define AMOUNT_SET_STR_TESTS_H
#include <stdbool.h>

bool test1();
bool test2();
bool test3();
bool test4();

#endif /*AMOUNT_SET_STR_TESTS_H*/